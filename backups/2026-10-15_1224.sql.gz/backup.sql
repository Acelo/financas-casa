--
-- PostgreSQL database dump
--

\restrict htIlXHr8nDfgpF0ZbVlAOoG27Ybc4xR1uGhfBMdwfz9y6CHQlrMqm7k1gWuxbvf

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11 (Debian 17.11-1.pgdg13+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA public;


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: fn_juros_obra_sync(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.fn_juros_obra_sync() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    UPDATE public.lancamentos L
       SET valor_previsto = NEW.valor
         , valor_pago     = CASE
                                WHEN L.status = 'pago' THEN NEW.valor
                                ELSE L.valor_pago
                            END
     WHERE 1 = 1
       AND L.competencia = NEW.competencia
       AND L.conta_id IN (
               SELECT C.id
                 FROM public.contas C
                WHERE 1 = 1
                  AND C.origem_valor = 'juros_obra'
           );
    RETURN NEW;
END;
$$;


--
-- Name: fn_set_updated_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.fn_set_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at := now();
    RETURN NEW;
END;
$$;


--
-- Name: gerar_lancamentos(date); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.gerar_lancamentos(p_competencia date) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_comp   DATE := date_trunc('month', p_competencia)::DATE;
    v_total  INTEGER;
BEGIN
    IF NOT public.is_membro() THEN
        RAISE EXCEPTION 'Acesso negado';
    END IF;

    INSERT INTO public.lancamentos (conta_id, competencia, valor_previsto, parcela)
    SELECT C.id
         , v_comp
         , COALESCE(
               CASE
                   WHEN C.origem_valor = 'juros_obra' THEN (
                        SELECT J.valor
                          FROM public.juros_obra J
                         WHERE 1 = 1
                           AND J.competencia <= v_comp
                         ORDER BY J.competencia DESC
                         LIMIT 1
                   )
                   WHEN C.tipo_valor = 'variavel' THEN (
                        SELECT L.valor_pago
                          FROM public.lancamentos L
                         WHERE 1 = 1
                           AND L.conta_id = C.id
                           AND L.competencia < v_comp
                           AND L.valor_pago IS NOT NULL
                         ORDER BY L.competencia DESC
                         LIMIT 1
                   )
               END
             , (
                   SELECT V.valor
                     FROM public.conta_valores V
                    WHERE 1 = 1
                      AND V.conta_id = C.id
                      AND V.vigente_desde <= v_comp
                    ORDER BY V.vigente_desde DESC
                    LIMIT 1
               )
             , 0
           )
         , CASE
               WHEN C.parcelas_totais IS NOT NULL THEN COALESCE(ULT.parcela, 0) + 1
           END
      FROM public.contas C
      LEFT JOIN LATERAL (
               SELECT L.parcela
                 FROM public.lancamentos L
                WHERE 1 = 1
                  AND L.conta_id = C.id
                  AND L.competencia < v_comp
                ORDER BY L.competencia DESC
                LIMIT 1
           ) ULT ON true
     WHERE 1 = 1
       AND C.ativo
       AND C.recorrente
       AND C.gera_lancamento
       AND (   C.parcelas_totais IS NULL
            OR COALESCE(ULT.parcela, 0) < C.parcelas_totais)
       AND NOT EXISTS (
               SELECT 1
                 FROM public.lancamentos L
                WHERE 1 = 1
                  AND L.conta_id = C.id
                  AND L.competencia = v_comp
           );

    GET DIAGNOSTICS v_total = ROW_COUNT;
    RETURN v_total;
END;
$$;


--
-- Name: is_membro(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.is_membro() RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
    SELECT EXISTS (
        SELECT 1
          FROM public.membros M
         WHERE 1 = 1
           AND lower(M.email) = lower(auth.jwt() ->> 'email')
    );
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: backups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.backups (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tipo text NOT NULL,
    arquivo text,
    tamanho_bytes bigint,
    criado_por text DEFAULT (auth.jwt() ->> 'email'::text),
    criado_em timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT backups_tipo_check CHECK ((tipo = ANY (ARRAY['manual'::text, 'automatico'::text])))
);


--
-- Name: conta_valores; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.conta_valores (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    conta_id uuid NOT NULL,
    valor numeric(12,2) NOT NULL,
    vigente_desde date NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT conta_valores_valor_check CHECK ((valor >= (0)::numeric)),
    CONSTRAINT conta_valores_vigente_desde_check CHECK ((EXTRACT(day FROM vigente_desde) = (1)::numeric))
);


--
-- Name: contas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contas (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    nome text NOT NULL,
    categoria text NOT NULL,
    tipo_valor text DEFAULT 'fixo'::text NOT NULL,
    origem_valor text DEFAULT 'manual'::text NOT NULL,
    dia_vencimento smallint,
    forma_pagamento text,
    gera_lancamento boolean DEFAULT true NOT NULL,
    recorrente boolean DEFAULT true NOT NULL,
    ativo boolean DEFAULT true NOT NULL,
    parcelas_totais integer,
    obs text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT contas_dia_vencimento_check CHECK (((dia_vencimento >= 1) AND (dia_vencimento <= 31))),
    CONSTRAINT contas_origem_valor_check CHECK ((origem_valor = ANY (ARRAY['manual'::text, 'juros_obra'::text]))),
    CONSTRAINT contas_parcelas_totais_check CHECK ((parcelas_totais > 0)),
    CONSTRAINT contas_tipo_valor_check CHECK ((tipo_valor = ANY (ARRAY['fixo'::text, 'variavel'::text])))
);


--
-- Name: juros_obra; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.juros_obra (
    competencia date NOT NULL,
    valor numeric(12,2) NOT NULL,
    data_pagamento date,
    obs text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT juros_obra_competencia_check CHECK ((EXTRACT(day FROM competencia) = (1)::numeric)),
    CONSTRAINT juros_obra_valor_check CHECK ((valor >= (0)::numeric))
);


--
-- Name: lancamentos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lancamentos (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    conta_id uuid NOT NULL,
    competencia date NOT NULL,
    valor_previsto numeric(12,2) DEFAULT 0 NOT NULL,
    valor_pago numeric(12,2),
    data_pagamento date,
    status text DEFAULT 'pendente'::text NOT NULL,
    parcela integer,
    obs text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT lancamentos_competencia_check CHECK ((EXTRACT(day FROM competencia) = (1)::numeric)),
    CONSTRAINT lancamentos_status_check CHECK ((status = ANY (ARRAY['pendente'::text, 'pago'::text])))
);


--
-- Name: membros; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.membros (
    email text NOT NULL,
    nome text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: receitas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.receitas (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    competencia date NOT NULL,
    pessoa text NOT NULL,
    tipo text NOT NULL,
    descricao text,
    valor numeric(12,2) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT receitas_competencia_check CHECK ((EXTRACT(day FROM competencia) = (1)::numeric)),
    CONSTRAINT receitas_tipo_check CHECK ((tipo = ANY (ARRAY['salario'::text, 'extra'::text]))),
    CONSTRAINT receitas_valor_check CHECK ((valor >= (0)::numeric))
);


--
-- Name: v_juros_obra; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_juros_obra WITH (security_invoker='true') AS
 SELECT competencia,
    valor,
    data_pagamento,
    obs,
    (valor - lag(valor) OVER (ORDER BY competencia)) AS variacao,
    round((((valor - lag(valor) OVER (ORDER BY competencia)) / NULLIF(lag(valor) OVER (ORDER BY competencia), (0)::numeric)) * (100)::numeric), 2) AS variacao_pct
   FROM public.juros_obra j;


--
-- Data for Name: backups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.backups (id, tipo, arquivo, tamanho_bytes, criado_por, criado_em) FROM stdin;
\.


--
-- Data for Name: conta_valores; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.conta_valores (id, conta_id, valor, vigente_desde, created_at) FROM stdin;
a5127bcc-ccdd-4bfa-8d7a-4b82c5c711f7	ce6808c7-69f9-45fb-9da5-aeba45d16e0a	3000.00	2026-10-01	2026-10-15 12:08:40.205693+00
d09cfadc-bfd1-4959-8f9b-488aa78bfe48	3a864c48-4022-4df4-b502-611e9ae87e3f	850.00	2026-10-01	2026-10-15 12:08:40.205693+00
eaf27948-06fb-4a2f-b9df-9a2c1f450696	8f0984e1-4204-4915-985d-29c63435ed8f	381.27	2026-10-01	2026-10-15 12:08:40.205693+00
24399993-83e5-4929-95c0-d110523c9cac	a536c514-0a94-4fe6-8ee5-1f0388555130	1599.43	2026-10-01	2026-10-15 12:08:40.205693+00
05fd800f-8697-44e5-acb4-3e0230e45e97	56e3b2f3-c76e-4f59-b0bc-741c4e2d511d	1578.55	2026-10-01	2026-10-15 12:08:40.205693+00
583d1ee7-4297-40bb-8e8d-a3dc78d442a5	9ab40531-5d77-4e45-9a70-5721b45e913b	5326.04	2026-10-01	2026-10-15 12:08:40.205693+00
24d85d2c-0dbf-4304-bfcc-49f2b06641e7	7cf1e461-e7e5-4d31-a774-c545e0ce76c9	30.72	2026-10-01	2026-10-15 12:08:40.205693+00
fbda0b3c-e00a-4d4c-b3b3-9836ffd3a96e	7c10fdee-146d-4c5b-8bc4-6247b3d82b04	0.00	2026-10-01	2026-10-15 12:08:40.205693+00
bfb885a8-25da-497d-aaa7-d845ed04ce22	a19b52e3-3042-46b0-a005-094ba8c1d519	0.00	2026-10-01	2026-10-15 12:08:40.205693+00
5a955de3-0229-4d1d-9b97-6a278aac03b8	cb8000c1-e102-4ff0-af23-16de36d0ac9e	15.00	2026-10-01	2026-10-15 12:08:40.205693+00
a22e9d64-b9b6-4e80-95d3-3751a8d9c7e5	2f882b07-d68a-465e-8dc9-94f61241e571	15.00	2026-10-01	2026-10-15 12:08:40.205693+00
a15e1e6a-61ba-4f85-8bb4-e6c104c44fee	31448113-c92a-4041-9263-65caac5e8e1b	16.65	2026-10-01	2026-10-15 12:08:40.205693+00
a36fd0a8-2bce-4262-b924-df88ab30762a	15099e3f-0db2-49c9-8a3a-b5cadf62241c	0.00	2026-10-01	2026-10-15 12:08:40.205693+00
08ca04b2-595e-47b0-8921-f5f59872ef6c	c87bf969-5095-4391-8557-4153571b67e9	250.00	2026-10-01	2026-10-15 12:08:40.205693+00
b9a7ec5c-fe15-469f-8747-9b33ed681fbe	23595ff3-ee06-41f4-91df-9d8c3785da98	258.29	2026-10-01	2026-10-15 12:08:40.205693+00
82678315-9880-4b16-bb1c-69f8473af0df	f387772f-d0f3-43ce-a19e-913023a135b9	118.00	2026-10-01	2026-10-15 12:08:40.205693+00
b0b85e2e-c319-4c87-9957-e5427bd4a250	6fe19b27-3a33-4166-83c2-1413a6749714	360.98	2026-10-01	2026-10-15 12:08:40.205693+00
e2464b8c-2ea2-42d1-8aef-20d28a8bcd79	1eec259b-f4a4-46fa-9ccd-d628dc2f6836	531.62	2026-10-01	2026-10-15 12:08:40.205693+00
7328d3b9-ad25-474d-8ece-b84d0c661882	4befed83-35a5-43ff-94f7-f8da2c695940	100.00	2026-10-01	2026-10-15 12:08:40.205693+00
19542ca3-768a-4f5d-abd1-4a83e4b802c8	0ad45599-9263-4255-b984-791a417d040b	13.90	2026-10-01	2026-10-15 12:08:40.205693+00
6f678452-3ec8-4828-b0e2-21be4b6597a3	89598fc9-96d4-4b27-9ec5-ae96ddba67ef	44.90	2026-10-01	2026-10-15 12:08:40.205693+00
556e3d2a-c37e-4890-b8e8-cc9b4db42027	5353b91c-e51e-41cd-beee-f5fce1158ba9	46.82	2026-10-01	2026-10-15 12:08:40.205693+00
791cfdef-e42e-4fcc-a26a-575a0e88ae07	160cc604-6c68-4736-8e32-93de609c9d76	59.90	2026-10-01	2026-10-15 12:08:40.205693+00
1a4a75c6-fb44-4863-b978-0656f33f6f3f	8f59f3f6-5a01-4dee-9c2f-975305b2e8da	27.90	2026-10-01	2026-10-15 12:08:40.205693+00
6c4c1541-2cc9-4b46-a24d-5e6181a1cd75	c3ce2d02-4de7-4c02-a275-14e076f521c0	26.90	2026-10-01	2026-10-15 12:08:40.205693+00
cc7850de-9a19-43fe-9d6b-4652838b91b1	83190e95-f2d1-4acc-8a56-47a89a35381e	250.38	2026-10-01	2026-10-15 12:08:40.205693+00
4e3f01b0-ee8b-480b-a797-8460ed498a72	3beeafc7-7b0f-4529-8889-0b9a7062ffd6	8.90	2026-10-01	2026-10-15 12:08:40.205693+00
9ad9828a-cae5-4e4d-95a5-24d78216f91e	598b5e98-3d67-472d-9472-471c9d0aead5	19.90	2026-10-01	2026-10-15 12:08:40.205693+00
c65bbd65-5e56-48f8-8212-9acd65b7c8e2	9cccefad-9091-4ab3-bd84-ffc9be2305ab	5.95	2026-10-01	2026-10-15 12:08:40.205693+00
\.


--
-- Data for Name: contas; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.contas (id, nome, categoria, tipo_valor, origem_valor, dia_vencimento, forma_pagamento, gera_lancamento, recorrente, ativo, parcelas_totais, obs, created_at, updated_at) FROM stdin;
8f0984e1-4204-4915-985d-29c63435ed8f	Condomínio	Moradia	fixo	manual	12	Boleto	t	t	t	\N	\N	2026-10-15 12:08:40.205693+00	2026-10-15 12:08:40.205693+00
a536c514-0a94-4fe6-8ee5-1f0388555130	Carro	Financiamento	fixo	manual	7	Débito automático (Itaú)	t	t	t	60	\N	2026-10-15 12:08:40.205693+00	2026-10-15 12:08:40.205693+00
56e3b2f3-c76e-4f59-b0bc-741c4e2d511d	Cartão NU Tulio	Cartão	variavel	manual	9	\N	t	t	t	\N	\N	2026-10-15 12:08:40.205693+00	2026-10-15 12:08:40.205693+00
9ab40531-5d77-4e45-9a70-5721b45e913b	Cartão C6	Cartão	variavel	manual	10	\N	t	t	t	\N	\N	2026-10-15 12:08:40.205693+00	2026-10-15 12:08:40.205693+00
7cf1e461-e7e5-4d31-a774-c545e0ce76c9	Cartão NU Letícia	Cartão	variavel	manual	12	\N	t	t	t	\N	\N	2026-10-15 12:08:40.205693+00	2026-10-15 12:08:40.205693+00
7c10fdee-146d-4c5b-8bc4-6247b3d82b04	Cartão Carre4	Cartão	variavel	manual	8	\N	t	t	t	\N	\N	2026-10-15 12:08:40.205693+00	2026-10-15 12:08:40.205693+00
a19b52e3-3042-46b0-a005-094ba8c1d519	Cartão Saveg	Cartão	variavel	manual	10	\N	t	t	t	\N	Vem zerado caso não faça compras	2026-10-15 12:08:40.205693+00	2026-10-15 12:08:40.205693+00
cb8000c1-e102-4ff0-af23-16de36d0ac9e	Cartão Ponto (Let)	Cartão	variavel	manual	13	\N	t	t	t	\N	\N	2026-10-15 12:08:40.205693+00	2026-10-15 12:08:40.205693+00
2f882b07-d68a-465e-8dc9-94f61241e571	Cartão Ponto (Tul)	Cartão	variavel	manual	13	\N	t	t	t	\N	\N	2026-10-15 12:08:40.205693+00	2026-10-15 12:08:40.205693+00
31448113-c92a-4041-9263-65caac5e8e1b	Cartão Passaí	Cartão	variavel	manual	\N	\N	t	t	t	\N	\N	2026-10-15 12:08:40.205693+00	2026-10-15 12:08:40.205693+00
15099e3f-0db2-49c9-8a3a-b5cadf62241c	Cartão ITAU (Let)	Cartão	variavel	manual	\N	\N	t	t	t	\N	\N	2026-10-15 12:08:40.205693+00	2026-10-15 12:08:40.205693+00
c87bf969-5095-4391-8557-4153571b67e9	Energia (CPFL)	Moradia	variavel	manual	20	Boleto	t	t	t	\N	Média de referência: 250,00	2026-10-15 12:08:40.205693+00	2026-10-15 12:08:40.205693+00
23595ff3-ee06-41f4-91df-9d8c3785da98	FIES	Financiamento	fixo	manual	11	Boleto	t	t	t	177	\N	2026-10-15 12:08:40.205693+00	2026-10-15 12:08:40.205693+00
f387772f-d0f3-43ce-a19e-913023a135b9	Internet	Serviços	fixo	manual	12	Boleto	t	t	t	\N	- 10 reais se pagar no prazo	2026-10-15 12:08:40.205693+00	2026-10-15 12:08:40.205693+00
6fe19b27-3a33-4166-83c2-1413a6749714	Empréstimo NU	Financiamento	fixo	manual	10	\N	t	t	f	12	Finalizado em 10/2026	2026-10-15 12:08:40.205693+00	2026-10-15 12:08:40.205693+00
1eec259b-f4a4-46fa-9ccd-d628dc2f6836	IPVA	Impostos	fixo	manual	13	Nubank	t	t	f	5	Finalizado em 10/2026	2026-10-15 12:08:40.205693+00	2026-10-15 12:08:40.205693+00
4befed83-35a5-43ff-94f7-f8da2c695940	Dentista	Saúde	fixo	manual	\N	Dinheiro	t	f	t	\N	Gasto avulso	2026-10-15 12:08:40.205693+00	2026-10-15 12:08:40.205693+00
0ad45599-9263-4255-b984-791a417d040b	Prime	Streaming	fixo	manual	\N	Crédito	f	t	f	12	\N	2026-10-15 12:08:40.205693+00	2026-10-15 12:08:40.205693+00
89598fc9-96d4-4b27-9ec5-ae96ddba67ef	HBO Max	Streaming	fixo	manual	15	Crédito	f	t	t	12	\N	2026-10-15 12:08:40.205693+00	2026-10-15 12:08:40.205693+00
5353b91c-e51e-41cd-beee-f5fce1158ba9	Disney Plus	Streaming	fixo	manual	\N	Crédito	f	t	f	\N	\N	2026-10-15 12:08:40.205693+00	2026-10-15 12:08:40.205693+00
160cc604-6c68-4736-8e32-93de609c9d76	Netflix	Streaming	fixo	manual	2	Crédito	f	t	f	\N	\N	2026-10-15 12:08:40.205693+00	2026-10-15 12:08:40.205693+00
c3ce2d02-4de7-4c02-a275-14e076f521c0	Youtube	Streaming	fixo	manual	12	Crédito	f	t	t	\N	\N	2026-10-15 12:08:40.205693+00	2026-10-15 12:08:40.205693+00
83190e95-f2d1-4acc-8a56-47a89a35381e	Seguro Youse	Seguro	fixo	manual	8	Crédito	f	t	t	\N	\N	2026-10-15 12:08:40.205693+00	2026-10-15 12:08:40.205693+00
3beeafc7-7b0f-4529-8889-0b9a7062ffd6	Meli +	Serviços	fixo	manual	\N	Crédito	f	t	t	\N	\N	2026-10-15 12:08:40.205693+00	2026-10-15 12:08:40.205693+00
598b5e98-3d67-472d-9472-471c9d0aead5	iCloud	Serviços	fixo	manual	6	Crédito	f	t	t	\N	\N	2026-10-15 12:08:40.205693+00	2026-10-15 12:08:40.205693+00
3a864c48-4022-4df4-b502-611e9ae87e3f	Aluguel	Moradia	fixo	manual	10	PIX	t	t	t	\N	Pix para Fatima Sueli Heluani Dias (Salvo no C6 Bank)	2026-10-15 12:08:40.205693+00	2026-10-15 13:27:30.817943+00
8f59f3f6-5a01-4dee-9c2f-975305b2e8da	Spotify	Streaming	fixo	manual	6	Crédito	f	t	f	\N	\N	2026-10-15 12:08:40.205693+00	2026-10-15 13:28:25.23626+00
9cccefad-9091-4ab3-bd84-ffc9be2305ab	iFood	Serviços	fixo	manual	24	Crédito	f	t	t	\N	\N	2026-10-15 12:08:40.205693+00	2026-10-15 13:29:18.515046+00
ce6808c7-69f9-45fb-9da5-aeba45d16e0a	Apartamento	Financiamento	variavel	juros_obra	10	Débito automático (Caixa)	t	t	t	\N	Juros de obra. Na planilha de fixos: Apto Novo, estimativa 3.000	2026-10-15 12:08:40.205693+00	2026-10-15 14:51:44.656945+00
\.


--
-- Data for Name: juros_obra; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.juros_obra (competencia, valor, data_pagamento, obs, created_at, updated_at) FROM stdin;
2026-03-01	1818.18	2026-03-10	\N	2026-10-15 12:08:40.205693+00	2026-10-15 12:08:40.205693+00
2026-04-01	1292.52	2026-04-10	\N	2026-10-15 12:08:40.205693+00	2026-10-15 12:08:40.205693+00
2026-05-01	1654.41	2026-05-10	\N	2026-10-15 12:08:40.205693+00	2026-10-15 12:08:40.205693+00
2026-06-01	2026.14	2026-06-10	\N	2026-10-15 12:08:40.205693+00	2026-10-15 12:08:40.205693+00
2026-07-01	2029.32	2026-07-10	\N	2026-10-15 12:08:40.205693+00	2026-10-15 12:08:40.205693+00
2026-08-01	2342.94	2026-08-10	\N	2026-10-15 12:08:40.205693+00	2026-10-15 12:08:40.205693+00
2026-09-01	2247.74	2026-09-10	\N	2026-10-15 12:08:40.205693+00	2026-10-15 12:08:40.205693+00
2026-10-01	2533.12	2026-10-10	\N	2026-10-15 12:08:40.205693+00	2026-10-15 12:08:40.205693+00
2026-11-01	2600.00	\N	teste	2026-10-15 14:51:21.577853+00	2026-10-15 14:51:21.577853+00
\.


--
-- Data for Name: lancamentos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.lancamentos (id, conta_id, competencia, valor_previsto, valor_pago, data_pagamento, status, parcela, obs, created_at, updated_at) FROM stdin;
5c497295-e18e-4a6f-b396-68dbaf7bb92e	ce6808c7-69f9-45fb-9da5-aeba45d16e0a	2026-10-01	2533.12	2533.12	\N	pago	\N	\N	2026-10-15 12:08:40.205693+00	2026-10-15 12:08:40.205693+00
5321373d-2f54-45c3-b4ff-47b1cec55110	3a864c48-4022-4df4-b502-611e9ae87e3f	2026-10-01	850.00	850.00	\N	pago	\N	\N	2026-10-15 12:08:40.205693+00	2026-10-15 12:08:40.205693+00
a2f3d0e6-063f-4de2-83a3-7b4f08aabfc3	8f0984e1-4204-4915-985d-29c63435ed8f	2026-10-01	381.27	381.27	\N	pago	\N	\N	2026-10-15 12:08:40.205693+00	2026-10-15 12:08:40.205693+00
7c0bacd8-84dd-4180-8e7a-9b00e71a324f	a536c514-0a94-4fe6-8ee5-1f0388555130	2026-10-01	1599.43	1599.43	\N	pago	14	\N	2026-10-15 12:08:40.205693+00	2026-10-15 12:08:40.205693+00
6daa4417-0ebf-4861-bd4d-b38fc0cebb9d	56e3b2f3-c76e-4f59-b0bc-741c4e2d511d	2026-10-01	1578.55	1578.55	\N	pago	\N	\N	2026-10-15 12:08:40.205693+00	2026-10-15 12:08:40.205693+00
2543b6ee-3495-4bc5-a96c-ad60c4fc1dd7	9ab40531-5d77-4e45-9a70-5721b45e913b	2026-10-01	5326.04	5326.04	\N	pago	\N	\N	2026-10-15 12:08:40.205693+00	2026-10-15 12:08:40.205693+00
5edf253e-f5bc-4323-9602-64fd99c45d5d	7cf1e461-e7e5-4d31-a774-c545e0ce76c9	2026-10-01	30.72	30.72	\N	pago	\N	\N	2026-10-15 12:08:40.205693+00	2026-10-15 12:08:40.205693+00
1fe6ef88-a7fe-45b8-8888-85263854ce06	7c10fdee-146d-4c5b-8bc4-6247b3d82b04	2026-10-01	0.00	0.00	\N	pago	\N	\N	2026-10-15 12:08:40.205693+00	2026-10-15 12:08:40.205693+00
8d2178fb-375e-40ed-94e5-511f888fda7f	a19b52e3-3042-46b0-a005-094ba8c1d519	2026-10-01	0.00	0.00	\N	pago	\N	\N	2026-10-15 12:08:40.205693+00	2026-10-15 12:08:40.205693+00
ad83e9c3-8443-40cd-9f9e-e9b016b886b3	cb8000c1-e102-4ff0-af23-16de36d0ac9e	2026-10-01	15.00	15.00	\N	pago	\N	\N	2026-10-15 12:08:40.205693+00	2026-10-15 12:08:40.205693+00
f8ad4ddf-11b6-4e12-962a-8d15e99fd375	2f882b07-d68a-465e-8dc9-94f61241e571	2026-10-01	15.00	15.00	\N	pago	\N	\N	2026-10-15 12:08:40.205693+00	2026-10-15 12:08:40.205693+00
a5bf804a-26cc-4ec1-be95-3c194f103acb	31448113-c92a-4041-9263-65caac5e8e1b	2026-10-01	16.65	16.65	\N	pago	\N	\N	2026-10-15 12:08:40.205693+00	2026-10-15 12:08:40.205693+00
4086bca6-c32d-4706-ab72-34fd5adb906b	15099e3f-0db2-49c9-8a3a-b5cadf62241c	2026-10-01	0.00	0.00	\N	pago	\N	\N	2026-10-15 12:08:40.205693+00	2026-10-15 12:08:40.205693+00
b05c39db-26a0-40a2-b488-0c4fbe1e507f	c87bf969-5095-4391-8557-4153571b67e9	2026-10-01	267.74	267.74	\N	pago	\N	\N	2026-10-15 12:08:40.205693+00	2026-10-15 12:08:40.205693+00
fb8f87e9-734f-422e-8b40-f2827ae22d86	23595ff3-ee06-41f4-91df-9d8c3785da98	2026-10-01	258.29	258.29	\N	pago	111	\N	2026-10-15 12:08:40.205693+00	2026-10-15 12:08:40.205693+00
27a295cb-0d16-4965-a4af-f8817d8f0d70	f387772f-d0f3-43ce-a19e-913023a135b9	2026-10-01	118.00	118.00	\N	pago	\N	\N	2026-10-15 12:08:40.205693+00	2026-10-15 12:08:40.205693+00
06b600ae-31ff-497a-b840-35e66f5c2057	4befed83-35a5-43ff-94f7-f8da2c695940	2026-10-01	100.00	100.00	\N	pago	\N	\N	2026-10-15 12:08:40.205693+00	2026-10-15 12:08:40.205693+00
ce8c6632-00d6-47ba-a3d4-3da696db7dc5	8f0984e1-4204-4915-985d-29c63435ed8f	2026-11-01	381.27	\N	\N	pendente	\N	\N	2026-10-15 14:48:59.825275+00	2026-10-15 14:48:59.825275+00
0cdaded5-60e3-4bb9-b002-0e8324e14f60	a536c514-0a94-4fe6-8ee5-1f0388555130	2026-11-01	1599.43	\N	\N	pendente	15	\N	2026-10-15 14:48:59.825275+00	2026-10-15 14:48:59.825275+00
63ba30f7-47a7-4025-9917-ad47bdb26a76	56e3b2f3-c76e-4f59-b0bc-741c4e2d511d	2026-11-01	1578.55	\N	\N	pendente	\N	\N	2026-10-15 14:48:59.825275+00	2026-10-15 14:48:59.825275+00
e4e62b96-f58e-44d6-849c-1ef6300dc0ff	9ab40531-5d77-4e45-9a70-5721b45e913b	2026-11-01	5326.04	\N	\N	pendente	\N	\N	2026-10-15 14:48:59.825275+00	2026-10-15 14:48:59.825275+00
4d0a52c9-4889-4479-8594-5434a03d3b23	7cf1e461-e7e5-4d31-a774-c545e0ce76c9	2026-11-01	30.72	\N	\N	pendente	\N	\N	2026-10-15 14:48:59.825275+00	2026-10-15 14:48:59.825275+00
3b3cea56-d151-4b26-bc0d-8205ad0c75bf	7c10fdee-146d-4c5b-8bc4-6247b3d82b04	2026-11-01	0.00	\N	\N	pendente	\N	\N	2026-10-15 14:48:59.825275+00	2026-10-15 14:48:59.825275+00
8e37d857-83f6-4844-aaae-a7c62b9a2a87	a19b52e3-3042-46b0-a005-094ba8c1d519	2026-11-01	0.00	\N	\N	pendente	\N	\N	2026-10-15 14:48:59.825275+00	2026-10-15 14:48:59.825275+00
b3702b53-1e5f-4c0c-ab9a-94127bcc04e5	cb8000c1-e102-4ff0-af23-16de36d0ac9e	2026-11-01	15.00	\N	\N	pendente	\N	\N	2026-10-15 14:48:59.825275+00	2026-10-15 14:48:59.825275+00
8c3c226e-ffd1-46fb-accd-e1800ef848f1	2f882b07-d68a-465e-8dc9-94f61241e571	2026-11-01	15.00	\N	\N	pendente	\N	\N	2026-10-15 14:48:59.825275+00	2026-10-15 14:48:59.825275+00
d0028667-7a9f-4cc7-9b55-7ea566b9dbf0	31448113-c92a-4041-9263-65caac5e8e1b	2026-11-01	16.65	\N	\N	pendente	\N	\N	2026-10-15 14:48:59.825275+00	2026-10-15 14:48:59.825275+00
caf87fc6-524b-4d30-bfde-0e438d4a8ea9	15099e3f-0db2-49c9-8a3a-b5cadf62241c	2026-11-01	0.00	\N	\N	pendente	\N	\N	2026-10-15 14:48:59.825275+00	2026-10-15 14:48:59.825275+00
57d3f05d-bdee-4ee7-a6dc-97b3a820fab4	c87bf969-5095-4391-8557-4153571b67e9	2026-11-01	267.74	\N	\N	pendente	\N	\N	2026-10-15 14:48:59.825275+00	2026-10-15 14:48:59.825275+00
0443fdb0-6519-4354-bec8-ff6600991a9e	23595ff3-ee06-41f4-91df-9d8c3785da98	2026-11-01	258.29	\N	\N	pendente	112	\N	2026-10-15 14:48:59.825275+00	2026-10-15 14:48:59.825275+00
7ca38f75-533f-4951-958b-6404a59bc906	f387772f-d0f3-43ce-a19e-913023a135b9	2026-11-01	118.00	\N	\N	pendente	\N	\N	2026-10-15 14:48:59.825275+00	2026-10-15 14:48:59.825275+00
2531dc32-269e-4842-8a14-9f97570fccf0	3a864c48-4022-4df4-b502-611e9ae87e3f	2026-11-01	850.00	\N	\N	pendente	\N	\N	2026-10-15 14:48:59.825275+00	2026-10-15 14:48:59.825275+00
3599be1a-1341-41c9-902f-e1082454435a	ce6808c7-69f9-45fb-9da5-aeba45d16e0a	2026-11-01	2600.00	\N	\N	pendente	\N	\N	2026-10-15 14:48:59.825275+00	2026-10-15 14:51:21.577853+00
\.


--
-- Data for Name: membros; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.membros (email, nome, created_at) FROM stdin;
tulio.acelo@hotmail.com	Tulio	2026-10-15 12:08:40.205693+00
elinahdourado@gmail.com	Letícia	2026-10-15 12:08:40.205693+00
\.


--
-- Data for Name: receitas; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.receitas (id, competencia, pessoa, tipo, descricao, valor, created_at, updated_at) FROM stdin;
6cc524d7-9643-4266-9d02-7f1342bc0524	2026-10-01	Letícia	extra	PLR	1254.68	2026-10-15 13:17:08.515216+00	2026-10-15 13:17:08.515216+00
89589525-a5ad-4937-9c8b-f9c888e5780a	2026-10-01	Letícia	salario	\N	4827.19	2026-10-15 13:17:36.33058+00	2026-10-15 13:17:36.33058+00
16b7731b-8e82-4539-a07a-8c34f0e11e92	2026-10-01	Tulio	salario	\N	5581.51	2026-10-15 13:18:18.716817+00	2026-10-15 13:18:18.716817+00
a5744436-5cb0-4ae0-b00e-00e5a5974e23	2026-10-01	Tulio	extra	Mãe (Condomínio)	500.00	2026-10-15 13:18:36.566723+00	2026-10-15 13:18:36.566723+00
684ecdc9-5376-43a3-a378-c6e0088f4b89	2026-10-01	Tulio	extra	Caju	500.00	2026-10-15 14:23:49.505639+00	2026-10-15 14:23:49.505639+00
\.


--
-- Name: backups backups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.backups
    ADD CONSTRAINT backups_pkey PRIMARY KEY (id);


--
-- Name: conta_valores conta_valores_conta_id_vigente_desde_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conta_valores
    ADD CONSTRAINT conta_valores_conta_id_vigente_desde_key UNIQUE (conta_id, vigente_desde);


--
-- Name: conta_valores conta_valores_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conta_valores
    ADD CONSTRAINT conta_valores_pkey PRIMARY KEY (id);


--
-- Name: contas contas_nome_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contas
    ADD CONSTRAINT contas_nome_key UNIQUE (nome);


--
-- Name: contas contas_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contas
    ADD CONSTRAINT contas_pkey PRIMARY KEY (id);


--
-- Name: juros_obra juros_obra_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.juros_obra
    ADD CONSTRAINT juros_obra_pkey PRIMARY KEY (competencia);


--
-- Name: lancamentos lancamentos_conta_id_competencia_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lancamentos
    ADD CONSTRAINT lancamentos_conta_id_competencia_key UNIQUE (conta_id, competencia);


--
-- Name: lancamentos lancamentos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lancamentos
    ADD CONSTRAINT lancamentos_pkey PRIMARY KEY (id);


--
-- Name: membros membros_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.membros
    ADD CONSTRAINT membros_pkey PRIMARY KEY (email);


--
-- Name: receitas receitas_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.receitas
    ADD CONSTRAINT receitas_pkey PRIMARY KEY (id);


--
-- Name: backups_criado_em_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX backups_criado_em_idx ON public.backups USING btree (criado_em DESC);


--
-- Name: lancamentos_competencia_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX lancamentos_competencia_idx ON public.lancamentos USING btree (competencia);


--
-- Name: receitas_competencia_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX receitas_competencia_idx ON public.receitas USING btree (competencia);


--
-- Name: contas trg_contas_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_contas_updated_at BEFORE UPDATE ON public.contas FOR EACH ROW EXECUTE FUNCTION public.fn_set_updated_at();


--
-- Name: juros_obra trg_juros_obra_sync; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_juros_obra_sync AFTER INSERT OR UPDATE OF valor ON public.juros_obra FOR EACH ROW EXECUTE FUNCTION public.fn_juros_obra_sync();


--
-- Name: juros_obra trg_juros_obra_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_juros_obra_updated_at BEFORE UPDATE ON public.juros_obra FOR EACH ROW EXECUTE FUNCTION public.fn_set_updated_at();


--
-- Name: lancamentos trg_lancamentos_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_lancamentos_updated_at BEFORE UPDATE ON public.lancamentos FOR EACH ROW EXECUTE FUNCTION public.fn_set_updated_at();


--
-- Name: receitas trg_receitas_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_receitas_updated_at BEFORE UPDATE ON public.receitas FOR EACH ROW EXECUTE FUNCTION public.fn_set_updated_at();


--
-- Name: conta_valores conta_valores_conta_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conta_valores
    ADD CONSTRAINT conta_valores_conta_id_fkey FOREIGN KEY (conta_id) REFERENCES public.contas(id) ON DELETE CASCADE;


--
-- Name: lancamentos lancamentos_conta_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lancamentos
    ADD CONSTRAINT lancamentos_conta_id_fkey FOREIGN KEY (conta_id) REFERENCES public.contas(id) ON DELETE RESTRICT;


--
-- Name: backups; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.backups ENABLE ROW LEVEL SECURITY;

--
-- Name: backups backups_insert; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY backups_insert ON public.backups FOR INSERT TO authenticated WITH CHECK ((public.is_membro() AND (tipo = 'manual'::text)));


--
-- Name: backups backups_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY backups_select ON public.backups FOR SELECT TO authenticated USING (public.is_membro());


--
-- Name: conta_valores; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.conta_valores ENABLE ROW LEVEL SECURITY;

--
-- Name: conta_valores conta_valores_membros; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY conta_valores_membros ON public.conta_valores TO authenticated USING (public.is_membro()) WITH CHECK (public.is_membro());


--
-- Name: contas; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.contas ENABLE ROW LEVEL SECURITY;

--
-- Name: contas contas_membros; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY contas_membros ON public.contas TO authenticated USING (public.is_membro()) WITH CHECK (public.is_membro());


--
-- Name: juros_obra; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.juros_obra ENABLE ROW LEVEL SECURITY;

--
-- Name: juros_obra juros_obra_membros; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY juros_obra_membros ON public.juros_obra TO authenticated USING (public.is_membro()) WITH CHECK (public.is_membro());


--
-- Name: lancamentos; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.lancamentos ENABLE ROW LEVEL SECURITY;

--
-- Name: lancamentos lancamentos_membros; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY lancamentos_membros ON public.lancamentos TO authenticated USING (public.is_membro()) WITH CHECK (public.is_membro());


--
-- Name: membros; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.membros ENABLE ROW LEVEL SECURITY;

--
-- Name: membros membros_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY membros_select ON public.membros FOR SELECT TO authenticated USING (public.is_membro());


--
-- Name: receitas; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.receitas ENABLE ROW LEVEL SECURITY;

--
-- Name: receitas receitas_membros; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY receitas_membros ON public.receitas TO authenticated USING (public.is_membro()) WITH CHECK (public.is_membro());


--
-- PostgreSQL database dump complete
--

\unrestrict htIlXHr8nDfgpF0ZbVlAOoG27Ybc4xR1uGhfBMdwfz9y6CHQlrMqm7k1gWuxbvf

